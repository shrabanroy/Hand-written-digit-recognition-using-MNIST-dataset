# hand-written-digit-recognition-using-mnist-dataset
I use keras sequential modeling with tensorflow back end
